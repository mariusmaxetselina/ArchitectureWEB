from __future__ import unicode_literals

from django.apps import AppConfig


class EnigmesConfig(AppConfig):
    name = 'Enigmes'


class UserConfig(AppConfig):
    name = 'user'